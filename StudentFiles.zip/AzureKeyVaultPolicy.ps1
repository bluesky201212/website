# Replace the bracketed values below. Values should be the
# required information surrounded by single quotes (') with
# no brackets ([]) remaining.

$subscriptionName = '[Azure_Subscription_Name]'
$userPrincipalName = '[User_Account_With_Subscription_Access]'
$applicationId = '[Azure_AD_Application_ID]'
$resourceGroupName = '[Resource_Group_with_KeyVault]'
$location = '[Azure_Region_of_KeyVault]'
$vaultName = '[KeyVault_Name]' 

# No edits required below this line

Login-AzAccount


Set-AzKeyVaultAccessPolicy -VaultName $vaultName -ResourceGroupName $resourceGroupName `
    -PermissionsToKeys create,get,wrapKey,unwrapKey,sign,verify,list -UserPrincipalName $userPrincipalName
Set-AzKeyVaultAccessPolicy  -VaultName $vaultName  -ResourceGroupName $resourceGroupName `
    -ServicePrincipalName $applicationId -PermissionsToKeys get,wrapKey,unwrapKey,sign,verify,list